from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import InventoryItem, Category

admin.site.register(InventoryItem)

# Define a new UserAdmin class with id added to list_display
class UserAdmin(BaseUserAdmin):
    list_display = ('id', 'username', 'email', 'first_name', 'last_name', 'is_staff')

# Re-register the UserAdmin
admin.site.unregister(User)
admin.site.register(User, UserAdmin)