from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import InventoryItem, AuditTrail

@receiver(post_save, sender=InventoryItem)
def create_audit_entry(sender, instance, created, **kwargs):
    if created:
        version = 1  # Set the initial version to 1 for a newly created item
    else:
        latest_audit = AuditTrail.objects.filter(inventory_item=instance).order_by('-version').first()
        version = latest_audit.version + 1 if latest_audit else 1

    # Use the modified_by field from the InventoryItem model
    modified_by = instance.modified_by

    AuditTrail.objects.create(
        version=version,
        name=instance.name,
        quantity=instance.quantity,
        price=instance.price,
        user=instance.user,
        inventory_item=instance,
        modified_by=instance.modified_by  # Use the modified_by value from InventoryItem
    )
